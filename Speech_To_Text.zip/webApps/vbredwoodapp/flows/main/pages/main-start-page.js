define([], () => {
  'use strict';

  let editor;

  class PageModule {

    /**
     *
     * @param {String} arg1
     * @return {String}
     */
    // Code Mirror
    initializeCodeMirror() {
      document.addEventListener("DOMContentLoaded", function () {

      });
    }


    codeMirrorArea(initialValue) {
      let textArea = document.getElementById('code');

      if (editor) {
        // If an instance already exists, update its value
        editor.setValue(initialValue);
      } else {

        editor = CodeMirror.fromTextArea(textArea, {
          value: "Hello",
          lineNumbers: true,
          lineWrapping: true,
          readOnly: true
        });
        editor.setValue(initialValue);
      }
    }

    highlightText(query) {
      let cursor = editor.getSearchCursor(query);
      editor.getAllMarks().forEach(mark => mark.clear());
      while (cursor.findNext()) {
        editor.markText(cursor.from(), cursor.to(), {
          className: 'highlight'
        });
      }
    }


    copyStyles(src, dest) {
      const styles = window.getComputedStyle(src);
      const propertiesToCopy = [
        'font-style',
        'font-variant-ligatures',
        'font-variant-caps',
        'font-variant-numeric',
        'font-variant-east-asian',
        'font-variant-alternates',
        'font-variant-position',
        'font-weight',
        'font-stretch',
        'font-size',
        'font-family',
        'font-optical-sizing',
        'font-kerning',
        'font-feature-settings',
        'font-variation-settings',
        'text-rendering',
        'color',
        'letter-spacing',
        'word-spacing',
        'line-height',
        'text-transform',
        'text-indent',
        'text-shadow',
        'display',
        'text-align',
        'appearance',
        '-webkit-rtl-ordering',
        'cursor',
        'overflow-wrap',
        'background-color',
        'column-count',
        'margin',
        'border-width',
        'border-style',
        'border-color',
        'border-image',
        'padding',
        'white-space'
      ];

      propertiesToCopy.forEach(property => {
        dest.style[property] = styles.getPropertyValue(property);
      });
    }

    downloadFile(file_contents, fileName) {
      const url = URL.createObjectURL(new Blob([file_contents], { type: 'text/plain' }));
      document.getElementById('download-link').href = url;
      document.getElementById('download-link').download = fileName + ".txt";
    }

  }

  return PageModule;
});
