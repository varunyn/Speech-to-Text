define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FilePickerSelectChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {object[]} params.files 
     */
    async run(context, { files }) {
      const { $page, $flow, $application } = context;

      $page.variables.showDialog = true;
      $page.variables.fileName = files[0].name;

      const callRestObjectStorageUploadObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorage/uploadObject',
        uriParams: {
          objectName: files[0].name,
        },
        body: files[0],
      });

      if (callRestObjectStorageUploadObjectResult.status ===200) {

        const callRestBusinessObjectsCreateFilesResult = await Actions.callRest(context, {
          endpoint: 'businessObjects/create_Files',
          body: {
            fileName: files[0].name,
            filePath: `https://objectstorage.us-ashburn-1.oraclecloud.com/n/natdcshjumpstartprod/b/Lightning-Talk/o/${files[0].name}`,
          },
        });

        await Actions.fireNotificationEvent(context, {
          summary: 'File Uploaded Successfully',
          type: 'confirmation',
          displayMode: 'transient',
        });

        await Actions.fireDataProviderEvent(context, {
          refresh: null,
          target: $page.variables.filesListSDP,
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error occurred while uploading file',
          displayMode: 'transient',
        });
      }

      $page.variables.showDialog = false;

      await Actions.resetVariables(context, {
        variables: [
          '$page.variables.fileName',
        ],
      });
    }
  }

  return FilePickerSelectChain;
});
