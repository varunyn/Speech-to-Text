define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class TimedEventSTimerExpiredChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {number} params.interval 
     * @param {number} params.tick 
     * @param {number} params.skipped 
     * @param {boolean} params.throttled 
     */
    async run(context, { interval, tick, skipped, throttled }) {
      const { $page, $flow, $application } = context;

      await Actions.fireDataProviderEvent(context, {
        refresh: null,
        target: $page.variables.filesListSDP,
      });
    }
  }

  return TimedEventSTimerExpiredChain;
});
