define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      $page.variables.showDialog = true;

      const callRestInvokeFunctionPost20181201FunctionsFunctionIdActionsInvokeResult = await Actions.callRest(context, {
        endpoint: 'InvokeFunction/post20181201FunctionsFunctionIdActionsInvoke',
        uriParams: {
          functionId: 'ocid1.fnfunc.oc1.iad.aaaaaaaakmhanfieb72jdgdde6cbgfpdcytqmszjvnubgu767ippcu4v3mpa',
        },
        body: {
       "data": {
        "resourceName": current.item.data.name,
         "additionalDetails": {
            "bucketName": "Lightning-Talk"
        }
       }
      },
      });

      if (callRestInvokeFunctionPost20181201FunctionsFunctionIdActionsInvokeResult.status ===200) {
        await Actions.fireNotificationEvent(context, {
          summary: 'Function Invoke successfully',
          type: 'confirmation',
          displayMode: 'transient',
        });
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'There was error invoking function',
        });
      }

      $page.variables.showDialog = false;
    }
  }

  return ButtonActionChain;
});
