define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class HyperlinkClickChain extends ActionChain {

    /**
     * @param {Object} context
     * @param {Object} params
     * @param {any} params.key 
     * @param {number} params.index 
     * @param {any} params.current 
     */
    async run(context, { key, index, current }) {
      const { $page, $flow, $application } = context;

      $page.variables.fileName = current.row.fileName;

      const callRestObjectStorageGetTranscriptObjectResult = await Actions.callRest(context, {
        endpoint: 'ObjectStorage/getTranscriptObject',
        uriParams: {
          objectName: current.row.transcriptPath,
        },
        responseType: 'string',
        responseBodyFormat: 'text',
      });

      if (callRestObjectStorageGetTranscriptObjectResult.status === 200) {

        $page.variables.transcript = callRestObjectStorageGetTranscriptObjectResult.body;
      } else {
        await Actions.fireNotificationEvent(context, {
          summary: 'Error Getting Transcript',
          displayMode: 'transient',
        });
      }

      await $page.functions.codeMirrorArea($page.variables.transcript);
    }
  }

  return HyperlinkClickChain;
});
